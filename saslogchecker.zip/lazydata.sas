filename P1AB3BC7 list;

 %put NOTE- ;
 %put NOTE: Data for package SASLogChecker, version 0.2.0, license MIT; 
 %put NOTE: *** %superq(packageTitle) ***; 
 %put NOTE- Generated: 2026-10-28T15:25:46; 
 %put NOTE- Author(s): %superq(packageAuthor); 
 %put NOTE- Maintainer(s): %superq(packageMaintainer); 
 %put NOTE- ;
 %put NOTE- Write %nrstr(%%)helpPackage(SASLogChecker) for the description;
 %put NOTE- ;
 %put NOTE- *** START ***; 

data _null_;
 length lazyData $ 32767; lazyData = lowcase(symget("lazyData"));
run;
%put NOTE- ;
%put NOTE: Data for package SASLogChecker, version 0.2.0, license MIT;
%put NOTE- *** END ***;

/* lazydata.sas end */

